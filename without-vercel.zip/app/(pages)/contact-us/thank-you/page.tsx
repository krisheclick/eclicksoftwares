"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Container, Row, Col } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheckCircle } from "@fortawesome/free-solid-svg-icons";
import Styles from "@/components/common/thank-you.module.css";
import Link from "next/link";

const ScheduleCallSuccess = () => {
    const router = useRouter();
    const hasRun = useRef(false);
    const [counter, setCounter] = useState(30); // countdown in seconds

    useEffect(() => {
        // if (hasRun.current) return;
        // hasRun.current = true;

        const allowed = sessionStorage.getItem("contact-us-success");

        if (!allowed) {
            router.replace("/");
            return;
        }

        // countdown timer
        const countdown = setInterval(() => {
            setCounter((prev) => prev - 1);
        }, 1000);

        // redirect after 30 seconds
        const redirectTimer = setTimeout(() => {
            sessionStorage.removeItem("contact-us-success"); // remove only when redirecting
            router.replace("/");
        }, 30000);

        return () => {
            clearInterval(countdown);
            clearTimeout(redirectTimer);
        };
    }, [router]);

    return (
        <div className={Styles.successPage}>
            <Container>
                <Row className="justify-content-center">
                    <Col lg={6} className="text-center">
                        <div className={Styles.successContent}>
                            <div className={Styles.successIcon}>
                                <FontAwesomeIcon icon={faCheckCircle} />
                            </div>
                            <h1 className={Styles.successTitle}>
                                Thank You for Contacting Us!
                            </h1>

                            <p className={Styles.successMessage}>
                                We’ve received your message and truly appreciate you reaching out to us.
                                <br />
                                One of our team members will contact you shortly.
                                <br /><br />
                                Redirecting to the homepage in{" "}
                                <strong>{counter} second{counter !== 1 ? "s" : ""}</strong>.
                            </p>

                            <div className={`btn_wrap justify-content-center btn_center ${Styles.actionButtons ?? ''}`}>
                                <Link
                                    href="/"
                                    className={`eclick-btn-primary lg ${Styles.homeBtn ?? ''}`}
                                >
                                    <em>Go to Home Now</em>
                                </Link>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default ScheduleCallSuccess;
