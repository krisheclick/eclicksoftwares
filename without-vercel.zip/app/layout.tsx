import { Instrument_Sans, DM_Sans, Inter } from "next/font/google";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-bootstrap";
import { config } from "@fortawesome/fontawesome-svg-core";
import "@fortawesome/fontawesome-svg-core/styles.css";
config.autoAddCss = false;
import 'swiper/css';
import "swiper/css/autoplay";
import "@/app/globals.css";
import "@/app/responsive.css";
import Header from "@/components/common/header/Header";
import Footer from "@/components/common/footer/Footer";
import { ThemeProvider } from "@/context/ThemeContext";
import RouteLoader from "@/components/RouteLoader";
import seoData from "@/data/seo.json";
import Script from "next/script";
export const dynamic = 'force-dynamic';

const primaryFont = Instrument_Sans({
    variable: "--primary-font",
    subsets: ["latin"],
});

const secondaryFont = DM_Sans({
    variable: "--secondary-font",
    subsets: ["latin"],
});

const tertiaryFont = Inter({
    variable: "--tertiary-font",
    subsets: ["latin"],
});

// export const metadata: Metadata = {
//   title: "Eclick Softwares: Innovation-Driven Web Development & Digital Agency",
//   description: "Eclick Softwares is a top web design & development company offering innovative digital solutions to grow your business online. Book a Free Quote Today.",
// };

export async function generateMetadata() {
    return seoData;
}


export default async function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    let response = null;
    let sitedata = null;

    try {
        // const res = await fetch(API_URL, { cache: 'no-store' });
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}menu/07e44c0de79cdf07b8b1`, { cache: 'no-store' });
        if (!res.ok) throw new Error('API failed');
        response = await res.json();
    } catch (err) {
        console.error('API fetch failed:', err);
    }

    // Site Settings
    try {
        
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/site-setting`, { cache: 'no-store' });
        sitedata = await response.json();
    }catch(err: unknown){
        console.log('Site Settings API fetch failed:', (err as Error).message);
    }
  
  
  return (
        <ThemeProvider>
            <html lang="en">
                <body
                    className={`${primaryFont.variable} ${secondaryFont.variable} ${tertiaryFont.variable} antialiased`}
                >
                    <RouteLoader />
                    <Header sitedata={sitedata} menuData={response.response_data} />
                    <main role="main" className="mainContainer">{children}</main>
                    <Footer sitedata={sitedata} />
                    <Script
                            src="https://voiceassistant.eclickprojects.com/widget/widget.js"
                            strategy="afterInteractive"
                            data-key="0364d085-f963-430e-9c4f-1999a41df4b8"
                        />
                </body>
            </html>
        </ThemeProvider>
    );
}
