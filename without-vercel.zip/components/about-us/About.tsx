"use client";
import { useEffect, useState } from "react";
import Banner from "./banner/Banner";
import Clients from "@/components/clients/Clients";
import CalltoAction from "@/components/call-to-action/CalltoAction";
import MissionVission from "./MissionVission";
import Counters from "@/components/counters/Counters";
import WhatWeDo from "./WhatWeDo";
import { Col, Container, Row } from "react-bootstrap";
import Review_rating from "./Review_rating";
import WhatsKeep from "./keep/WhatsKeep";
import BannerSkeleton from "./banner/BannerSkeleton";
import CustomImage from "@/utils/CustomImage";
import WhatWeDoSkeleton from "./WhatWeDoSkeleton";
import MissionVissionSkeleton from "./MissionVissionSkeleton";
import SkeletonCounter from "../counters/SkeletonCounter";
import WhatsKeepSkeleton from "./keep/WhatsKeepSkeleton";
import Styles from "./style.module.css";

type UspCategory = {
    usp_category_title: string;
    usp_category_description: string;
    usps: Usp[];
}

type Usp = {
    usp_feature_image_path: string;
    usp_title: string;
    usp_short_description: string;
    usp_description: string;
    usp_feature_image: string;
}

type CounterItem = {
    site_counter_number: number;
    site_counter_simbol: string;
    site_counter_title: string;
}

type TeamMember = {
    team_feature_image_path: string;
    team_title: string;
    team_rating: string;
    team_designation: string;
    team_description: string;
    team_feature_image: string;
}

type Faq = {
    id?: number;
    question?: string;
    answer?: string;
}

type Technology = {
    id?: number;
    name?: string;
    icon?: string;
}

type BannerItem = {
    h6xu_image?: string;
    h6xu_title?: string;
    banner?: BannerItem;
}

type CounterData = {
    dz44_title?: string;
    dz44_heading?: string;
    counter?: CounterData;
};
type AboutcomponentData = {
    heading: string;
    page_feature_image: string;
    short_description: string;
    page_title: string;
    description: string;
    pages_custom_field: string;
    page_repeater_data: string;
    page_technologies_used: string | null;
    page_top_pick_team: string | null;
    page_teams_used: string;
    usp_categorys: UspCategory[];
    top_pick_team: TeamMember[] | null;
    faqs: Faq[];
    technologies: Technology[];
    recommend_team: TeamMember[];
    counter_data: string;
}
const Aboutcomponent = () => {
    const [aboutData, setAboutData] = useState<AboutcomponentData | null>(null);
    const [bannerData, setBannerData] = useState<BannerItem | null>(null);
    const [teamData, setTeam] = useState<TeamMember[] | null>(null);
    const [counterData, setCounterData] = useState<CounterData | null>(null);
    const [hasLoading, setLoading] = useState(true);

    const fetchData = async () => {
        setLoading(true);
        try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/page/about-us`);
            const { response_data } = await response.json();

            setAboutData(response_data);
            setTeam(response_data?.recommend_team);
        } catch (err: unknown) {
            console.error("Failed to fetch About Page:", (err as Error).message);
        } finally {
            setLoading(false);
        };
    }

    useEffect(() => {
        fetchData();
    }, []);

    useEffect(() => {
        if (aboutData) {
            if (aboutData?.pages_custom_field) {
                try {
                    const customResponse = JSON.parse(aboutData?.pages_custom_field ?? "{}");
                    const data = customResponse?.group_name;
                    setBannerData(data?.banner);
                    setCounterData(data?.counter);

                } catch (err: unknown) {
                    console.error("Error parsing custom field data:", (err as Error).message);
                }
            }
        }
    }, [aboutData]);

    const counters: CounterItem[] = JSON.parse(
        aboutData?.counter_data ?? "[]"
    );

    const customData = JSON.parse(
        aboutData?.pages_custom_field ?? "{}"
    );

    const poster = aboutData?.page_feature_image;

    return (
        <div className="about_page">
            {!hasLoading && bannerData ? (
                <Banner data={bannerData} />
            ) : (
                <BannerSkeleton />
            )}
            <div className={`sectionArea pt-xxl-3 pt-xl-2 ${Styles.about_section ?? ''}`}>
                <Container>
                    <Row className="rowGap justify-content-center gx-xl-5">
                        {poster && (
                            <Col lg={6}>
                                {!hasLoading ? (
                                    <CustomImage
                                        src={`${process.env.NEXT_PUBLIC_MEDIA_URL}/uploads/page_image/${poster}`}
                                        alt={aboutData?.page_title}
                                        className={`h-100 ${Styles.aboutPoster}`}
                                        style={{ objectFit: "cover" }}
                                    />
                                ) : (
                                    <figure className={`skeleton h-100 ${Styles.aboutPoster}`}></figure>
                                )}
                            </Col>
                        )}
                        <Col lg={poster ? 6 : 10} className="align-self-center">
                            <div className={`${Styles.about_content} ${poster ? '' : `text-center ${Styles.text_center}`}`}>
                                {!hasLoading ? (
                                    <>
                                        <h2 className={`title fw-bold ${Styles.page_title}`}>{aboutData?.page_title}</h2>
                                        <div
                                            className="editorText"
                                            dangerouslySetInnerHTML={{ __html: aboutData?.description || "" }}
                                        />
                                        <Review_rating hasLoading={hasLoading} data={customData?.group_name} />
                                    </>
                                ) : (
                                    <>
                                        <div className={`skeleton mb-2 ${Styles.skeletonTitle}`}></div>
                                        <div className={`skeleton w-75 ${Styles.skeletonTitle}`}></div>
                                        <div className="skeleton skeletonText w-100"></div>
                                        <div className="skeleton skeletonText w-100"></div>
                                        <div className="skeleton skeletonText w-100"></div>
                                        <div className="skeleton skeletonText w-100"></div>
                                        <div className="skeleton skeletonText w-100"></div>
                                        <div className="skeleton skeletonText w-75"></div>
                                        <div className="skeleton skeletonText w-50"></div>
                                    </>
                                )}
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>

            <CalltoAction spaceClass={Styles.spaceAdd} content={customData?.group_name} isLoading={hasLoading} />

            {!hasLoading && aboutData?.usp_categorys?.[1] ? (
                <WhatWeDo
                    data={aboutData.usp_categorys[1]}
                    services={
                        aboutData.usp_categorys[1].usps.map((item: Usp) => ({
                            wcp_title: item.usp_title,
                            wcp_short_description: item.usp_description,
                            wcp_icon_path: item.usp_feature_image_path,
                            wcp_icon: item.usp_feature_image,
                            wcp_slug: ''
                        }))
                    }
                />
            ) : (
                <WhatWeDoSkeleton />
            )}

            {!hasLoading && customData?.group_name ? (
                <MissionVission data={customData?.group_name} />
            ) : (
                <MissionVissionSkeleton />
            )}
            <div className={Styles.counter_section}>
                <Container>
                    <div className={`section-content ${Styles.section_content ?? ''}`}>
                        {!hasLoading ? (
                            <>
                                {counterData?.dz44_title && (
                                    <div className="small_title">{counterData.dz44_title}</div>
                                )}

                                <div className={`title fw-bold ${Styles.counterDatatitle ?? ''}`}
                                    dangerouslySetInnerHTML={{ __html: counterData?.dz44_heading || '' }}
                                />
                            </>
                        ) : (
                            <>
                                <div className={`skeleton small_title w-25 ${Styles.subtitle ?? ''}`}>&nbsp;</div>
                                <div className={`skeleton title fw-bold ${Styles.counterDatatitle ?? ''}`}>&nbsp;</div>
                            </>
                        )}
                    </div>
                    {!hasLoading ? (
                        <Counters hasLoading={hasLoading} counters={counters} />
                    ) : (
                        <SkeletonCounter />
                    )}
                </Container>
            </div>
            {!hasLoading && aboutData?.usp_categorys?.[0] ? (
                <WhatsKeep
                    data={aboutData?.usp_categorys?.[0]}
                />
            ) : (
                <WhatsKeepSkeleton />
            )}

            {/* {!hasLoading && teamData ? (
                <Teams content={customData?.group_name} data={teamData} />
            ) : (
                <TeamSkeleton />
            )} */}
            <Clients />
        </div>
    );
};

export default Aboutcomponent;
