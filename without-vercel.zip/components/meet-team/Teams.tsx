import { Container, Stack } from 'react-bootstrap';
import Styles from './style.module.css';
import Card from './Card';

type TeamMember = {
    team_feature_image_path: string;
    team_title: string;
    team_rating: string;
    team_designation: string;
    team_description: string;
    team_feature_image: string;
}

type Content = {
    hnd4_title?: string;
    hnd4_heading?: string;
    team?: Content;
}

interface Props {
    content?: Content;
    data?: TeamMember[];
}

const Teams = ({content, data }: Props) => {
    const team = content?.team;
    return (
        <div className={Styles.sectionArea}>
            <Container>
                <div className={`section-content text-center full ${Styles.section_content ?? ''}`}>
                    {team?.hnd4_title && (
                        <div className="small_title">{team.hnd4_title}</div>
                    )}
                    <div className={`title fw-bold text-black ${Styles.title ?? ''}`}
                        dangerouslySetInnerHTML={{ __html: team?.hnd4_heading || '' }}
                    />
                </div>
                <div className={Styles.cardList}>
                    <div className={Styles.cardRow}>
                        {data?.map((value, index) => (
                        <Stack className={Styles.cardItem} key={index}>
                            <Card
                                poster={value?.team_feature_image_path}
                                name={value?.team_title}
                                designation={value?.team_designation}
                            />
                        </Stack>
                        ))}
                    </div>
                </div>
            </Container>
        </div>
    )
}

export default Teams
