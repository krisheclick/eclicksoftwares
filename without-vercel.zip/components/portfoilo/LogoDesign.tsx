import Image from "next/image";
import { Col, Row } from "react-bootstrap";
import { useLetsConnect } from "@/utils/useLetsConnect";
import Styles from "./style.module.css";
import FancyboxWrapper from "@/utils/FancyboxWrapper";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";

type Portfolios = {
    portfolio_feature_image_path?: string;
    portfolio_title?: string;
    portfolio_description?: string;
};

type Props = {
    title: string;
    portfolios?: Portfolios[];
};

const LogoDesign = ({ title, portfolios = [] }: Props) => {

    const { openLetsConnectModal } = useLetsConnect();

    if (portfolios.length === 0) {
        return <p className="notFound text-center">{title} Portfolio items found.</p>;
    }

    return (
        <FancyboxWrapper>
            <Row className='rowGap gx-2 gx-sm-3 gx-xxl-4'>
                {portfolios.map((item, index) => (
                    <Col xl={3} md={4} xs={6} key={index}>
                        <a
                            href={`${process.env.NEXT_PUBLIC_MEDIA_URL}${item.portfolio_feature_image_path ?? ""}`}
                            className={Styles.logoBox}
                            data-fancybox="gallery"
                        >
                            <Image
                                src={`${process.env.NEXT_PUBLIC_MEDIA_URL}${item.portfolio_feature_image_path ?? ""}`}
                                alt={item.portfolio_title || "Logo Design Title"}
                                fill
                                priority
                            />
                        </a>
                    </Col>
                ))}
            </Row>

            {/* MODAL BUTTON */}
            {portfolios.length > 0 && (
                <div className={`btn_center ${Styles.btn_center ?? ''}`}>
                    <button type="button" className={`eclick-btn-view lg ${Styles.viewBtn ?? ''}`} onClick={() => openLetsConnectModal("general_lets_connect")}>
                        <span>
                            <FontAwesomeIcon icon={faEye} />
                        </span>
                        <em>View More Logo</em>
                    </button>
                </div>
            )}
        </FancyboxWrapper>
    );
};

export default LogoDesign;